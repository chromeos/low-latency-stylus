var NAVTREE_DATA =
[ [ "com.google.chromeos.lowlatencystylus", "reference/com/google/chromeos/lowlatencystylus/package-summary.html", [ [ "Classes", null, [ [ "BatchedMotionEvent", "reference/com/google/chromeos/lowlatencystylus/BatchedMotionEvent.html", null, null, null ], [ "BatchedMotionEvent.IterableMotionEvent", "reference/com/google/chromeos/lowlatencystylus/BatchedMotionEvent.IterableMotionEvent.html", null, null, null ], [ "InkDelegate", "reference/com/google/chromeos/lowlatencystylus/InkDelegate.html", null, null, null ], [ "InkOverlayView", "reference/com/google/chromeos/lowlatencystylus/InkOverlayView.html", null, null, null ] ]
, null, null ] ]
, null, null ] ]

;

