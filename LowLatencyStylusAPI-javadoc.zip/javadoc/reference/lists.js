var DATA = [
      { id:0, label:"com.google.chromeos.lowlatencystylus", link:"reference/com/google/chromeos/lowlatencystylus/package-summary.html", type:"package", deprecated:"false" },
      { id:1, label:"com.google.chromeos.lowlatencystylus.BatchedMotionEvent", link:"reference/com/google/chromeos/lowlatencystylus/BatchedMotionEvent.html", type:"class", deprecated:"false" },
      { id:2, label:"com.google.chromeos.lowlatencystylus.BatchedMotionEvent.IterableMotionEvent", link:"reference/com/google/chromeos/lowlatencystylus/BatchedMotionEvent.IterableMotionEvent.html", type:"class", deprecated:"false" },
      { id:3, label:"com.google.chromeos.lowlatencystylus.InkDelegate", link:"reference/com/google/chromeos/lowlatencystylus/InkDelegate.html", type:"class", deprecated:"false" },
      { id:4, label:"com.google.chromeos.lowlatencystylus.InkOverlayView", link:"reference/com/google/chromeos/lowlatencystylus/InkOverlayView.html", type:"class", deprecated:"false" }

    ];
